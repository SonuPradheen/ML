# TorchWrapper

A collections of frameworks with inferences modules.

## Architecture
- app
  - context
  - distributed
  - entrance
- nn
  - csrc
  - layer
  - loss
  - metric
- solver
  - checkpoint
  - convertor
  - solver
- transform
  - defaults
  - image
- utils
  - device
  - filesystem
  - kv
  - logger
  - parser
  - stats
  - string
  - viz

## Operators Details


# Reference